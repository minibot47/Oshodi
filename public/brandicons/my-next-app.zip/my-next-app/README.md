# My Next App

A Next.js 15 starter with Tailwind CSS v4.

## Getting Started

Install dependencies:
\`\`\`bash
npm install
\`\`\`

Run the dev server:
\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Stack
- **Next.js 15** (App Router)
- **Tailwind CSS v4**
- **TypeScript**
