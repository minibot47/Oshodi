export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="text-center">
        <h1 className="text-5xl font-bold tracking-tight text-gray-900 dark:text-white mb-4">
          My Next App
        </h1>
        <p className="text-lg text-gray-500 dark:text-gray-400 mb-8">
          Next.js + Tailwind CSS — ready to build 🚀
        </p>
        <a
          href="https://nextjs.org/docs"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block rounded-lg bg-black text-white dark:bg-white dark:text-black px-6 py-3 text-sm font-medium hover:opacity-80 transition-opacity"
        >
          Read the docs →
        </a>
      </div>
    </main>
  );
}
